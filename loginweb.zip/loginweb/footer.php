<footer>

    <div class="footer-container">
        <div class="footer-section">
            <strong><h4>Comunícate con nosotros</h4></strong>
            <p>Asistente Virtual</p>
            <p>Escríbenos: artesanosa3@gmail.com</p>
            <p>Llámanos: (000) 000 000</p>
            <p>Visítanos: <a href="https://maps.app.goo.gl/V1CuG2YofQDAvBEm9">Nuestra Tienda</a></p>
            <p>Síguenos en:
                <a href="https://www.facebook.com/profile.php?id=100063290216178&skip_nax_wizard=true"><i class='bx bxl-facebook-circle'></i></a>
                <a href="https://www.instagram.com/"><i class='bx bxl twitter'></i></a>
            </p>
        </div>
        <div class="footer-section">
                <strong><h4>Nosotros</h4></strong>
                <p >Conócenos</p>
                <p>Trabaja con nosotros</p>
                <p>Responsabilidad social</p>
                <a href="LReclamos.php" class="libro"><img src="imagenes/libro de reclamaciones.jpg" alt="LReclamaciones"
                        style="width: 70px; height: 50px;"></a>

            </div>
            <div class="footer-section">
                <h4>Te informamos</h4>
                <p>Descuentos!</p>
                <p>Ofertas</p>
            </div>
            <div class="footer-section">
                <h4>Atención al cliente</h4>
                <p>Tutorial de compra</p>
                <p>Horarios atención telefónica</p>
            </div>
            <div class="footer-section">
                <h4>Políticas y condiciones</h4>
                <p>Política de datos personales</p>
                <p>Derecho ARCO y privacidad</p>
            </div>
    </div>
    <a href="Index.php"><i class='bx bxs-caret-up-circle' id="up"></i></a>
</footer>
<script src="Public/script.js/script.js"></script>
</body>
</html>
