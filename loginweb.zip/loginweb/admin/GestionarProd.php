<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/adminPro.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/Menuadmin.css">
</head>

<body>
    <div class="sidebar">
        <img src="../imagenes/LOGO.png" alt="Logo">
        <a href="../admin/inicioAdmin.php">Inicio</a>
        <a href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a>
        <a href="../admin/GestionarProd.php">Gestionar Productos</a>
        <a href="../admin/VerOrden.php">Ver Pedidos</a>
        <a href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a>
        <a href="../admin/VerReclamos.php">Ver Reclamos</a>
        <a href="../admin/VerPagos.php">Ver Pagos</a>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Artesanías Catacaos</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/inicioAdmin.php">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/GestionarProd.php">Gestionar Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/VerOrden.php">Ver Pedidos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/VerReclamos.php">Ver Reclamos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/VerPagos.php">Ver Pagos</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="content">
        <div class="container mt-5">
            <h2 class="text-center mb-4">Gestión de Productos</h2>

            <?php
            @include '../Conexion.php';
            session_start();
            if (!isset($_SESSION['usuario_id'])) {
                header('location:../Login.php');
                exit;
            }

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $nombrep = mysqli_real_escape_string($conn, $_POST['nombre']);
                $descripcion = mysqli_real_escape_string($conn, $_POST['descripcion']);
                $precio = mysqli_real_escape_string($conn, $_POST['precio']);
                $stock = mysqli_real_escape_string($conn, $_POST['stock']);
                $id_artesano = mysqli_real_escape_string($conn, $_POST['artesano']);


                $query = "INSERT INTO productos (Nombre, Descripcion, Precio, Cantidad, Id_Artesano) 
                  VALUES ('$nombrep', '$descripcion', '$precio', '$stock', '$id_artesano')";

                if (mysqli_query($conn, $query)) {



                    $carpeta = "../imagenes/$id_producto";
                    if (!file_exists($carpeta)) {
                        mkdir($carpeta, 0777, true);
                    }

                    $imagen = $_FILES['imagen']['name'];
                    $imagenTmp = $_FILES['imagen']['tmp_name'];
                    $rutaImagen = "$carpeta/principal.jpg";

                    if (move_uploaded_file($imagenTmp, $rutaImagen)) {

                        $queryUpdate = "UPDATE productos SET Imagen = '$rutaImagen' WHERE Id_Producto = '$id_producto'";
                        if (mysqli_query($conn, $queryUpdate)) {
                            echo "<div class='alert alert-success'>Producto agregado exitosamente.</div>";
                        } else {
                            echo "<div class='alert alert-danger'>Error al guardar la ruta de la imagen en la base de datos.</div>";
                        }
                    } else {
                        echo "<div class='alert alert-danger'>Error al subir la imagen.</div>";
                    }
                } else {
                    echo "<div class='alert alert-danger'>Error al agregar el producto: " . mysqli_error($conn) . "</div>";
                }
            }

            $queryArtesanos = "SELECT Id_Artesano, Nombre, Apellido FROM artesano";
            $resultArtesanos = mysqli_query($conn, $queryArtesanos);
            ?>

            <h4 class="text-center">Agregar Nuevo Producto</h4>
            <form id="formAgregarProducto" method="POST" action="" enctype="multipart/form-data">
                <div class="mb-3 col-md-4">
                    <label for="nombre" class="form-label">Nombre:</label>
                    <input type="text" id="nombre" name="nombre" class="form-control" required>
                </div>

                <div class="mb-3 col-md-4">
                    <label for="descripcion" class="form-label">Descripción:</label>
                    <input type="text" id="descripcion" name="descripcion" class="form-control" required>
                </div>

                <div class="mb-3 col-md-4">
                    <label for="precio" class="form-label">Precio:</label>
                    <input type="number" id="precio" name="precio" class="form-control" step="0.01" required>
                </div>

                <div class="mb-3 col-md-4">
                    <label for="stock" class="form-label">Stock:</label>
                    <input type="number" id="stock" name="stock" class="form-control" required>
                </div>

                <div class="mb-3 col-md-4">
                    <label for="artesano" class="form-label">Artesano:</label>
                    <select id="artesano" name="artesano" class="form-control" required>
                        <?php
                        if (mysqli_num_rows($resultArtesanos) > 0) {
                            while ($artesano = mysqli_fetch_assoc($resultArtesanos)) {
                                echo "<option value='" . $artesano['Id_Artesano'] . "'>" . $artesano['Nombre'] . " " . $artesano['Apellido'] . "</option>";
                            }
                        } else {
                            echo "<option disabled>No hay artesanos registrados</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="imagen" class="form-label">Imagen del Producto:</label>
                    <input type="file" id="imagen" name="imagen" class="form-control" accept="image/*" required>
                </div>

                <button type="submit" class="btn btn-primary">Agregar Producto</button>
            </form>

            <h2 class="text-center mt-5">Lista de Productos</h2>
            <div class="table-responsive">
                <table class="table table-bordered table-striped text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>ID del Producto</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Precio</th>
                            <th>Stock</th>
                            <th>Id Artesano</th>
                            <th>Imagen</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT p.*, a.Nombre AS NombreArtesano, a.Apellido AS ApellidoArtesano 
                          FROM productos p 
                          JOIN artesano a ON p.Id_Artesano = a.Id_Artesano";
                        $result = mysqli_query($conn, $query);
                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                $id = $row['Id_Producto'];
                                $nombrep = $row['Nombre'];
                                $descripcion = $row['Descripcion'];
                                $precio = $row['Precio'];
                                $stock = $row['Cantidad'];
                                $id_artesano = $row['Id_Artesano'];
                                $imagen = $row['Imagen'];

                                $artesano = $row['NombreArtesano'] . " " . $row['ApellidoArtesano'];

                                echo "
                        <tr>
                            <td>{$id}</td>
                            <td>{$nombrep}</td>
                            <td>{$descripcion}</td>
                            <td>{$precio}</td>
                            <td>{$stock}</td>
                            <td>{$id_artesano}</td>
                            <td><img src='{$imagen}' alt='Imagen del producto' style='width: 50px; height: 50px;'></td>
                            <td>
                                <a href='editarproducto.php?id={$id}' class='btn btn-warning btn-sm'>Editar</a>
                            </td>
                        </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>No se encontraron productos</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</html>