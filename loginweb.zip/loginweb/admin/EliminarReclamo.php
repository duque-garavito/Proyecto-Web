<?php
@include '../Conexion.php';

session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('location:../Login.php');
}

// Verifica que se ha recibido un ID de reclamo
if (isset($_GET['id'])) {
    $id_reclamo = $_GET['id'];

    // Consulta para eliminar el reclamo
    $queryEliminar = "DELETE FROM reclamos WHERE id_reclamo = ?";
    $stmt = $conn->prepare($queryEliminar);
    $stmt->bind_param('i', $id_reclamo);

    if ($stmt->execute()) {
        // Redirige de vuelta a la página de reclamos con un mensaje de éxito
        header('Location: VerReclamos.php?mensaje=Reclamo eliminado correctamente');
        exit();
    } else {
        // Manejo de errores
        echo "Error al eliminar el reclamo: " . $conn->error;
    }
} else {
    // Redirige si no se ha recibido un ID
    header('Location: VerReclamos.php');
    exit();
}
?>
