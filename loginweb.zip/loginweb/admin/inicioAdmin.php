<?php
@include '../Conexion.php';

session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('location:../Login.php');
    exit;
}

// Pedidos entregados por mes
$entregadosPorMes = [];
$result = $conn->query("SELECT MONTH(Fecha) AS mes, COUNT(*) AS total 
    FROM orden 
    WHERE Estado = 'Entregado' AND YEAR(Fecha) = YEAR(CURDATE()) 
    GROUP BY MONTH(Fecha)");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $entregadosPorMes[] = $row;
    }
} else {
    echo "Error en consulta Pedidos Entregados: " . $conn->error;
}

// Reclamaciones por estado
$reclamacionesEstado = [];
$result = $conn->query("SELECT Estado, COUNT(*) AS total FROM reclamos GROUP BY Estado");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $reclamacionesEstado[] = $row;
    }
} else {
    echo "Error en consulta Reclamaciones: " . $conn->error;
}

// Productos más vendidos
$productosMasVendidos = [];
$result = $conn->query("SELECT Nombre_Producto, SUM(Cantidad) AS total 
    FROM detalle_orden 
    GROUP BY Nombre_Producto 
    ORDER BY total DESC 
    LIMIT 10");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $productosMasVendidos[] = $row;
    }
} else {
    echo "Error en consulta Productos Más Vendidos: " . $conn->error;
}

// Listado general
$queryUsuarios = "SELECT * FROM usuario";
$resultUsuarios = mysqli_query($conn, $queryUsuarios);

$queryProductos = "SELECT * FROM productos";
$resultProductos = mysqli_query($conn, $queryProductos);

$queryOrdenes = "SELECT o.Id_Orden, o.Fecha, o.Total, u.Nombre, u.Apellido 
                 FROM orden o
                 JOIN usuario u ON o.Id_Usuario = u.Id_Usuario";
$resultOrdenes = mysqli_query($conn, $queryOrdenes);

$queryArtesanos = "SELECT * FROM artesano";
$resultArtesanos = mysqli_query($conn, $queryArtesanos);
?>



<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/Menuadmin.css">
    <link rel="stylesheet" href="../css/Graficos.css">
</head>

<!-- Sidebar(Menú vertical) -->

<body>

    <div class="sidebar">
        <img src="../imagenes/LOGO.png" alt="Logo">
        <a href="../admin/inicioAdmin.php">Inicio</a>
        <a href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a>
        <a href="../admin/GestionarProd.php">Gestionar Productos</a>
        <a href="../admin/VerOrden.php">Ver Pedidos</a>
        <a href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a>
        <a href="../admin/VerReclamos.php">Ver Reclamos</a>
        <a href="../admin/VerPagos.php">Ver Pagos</a>
    </div>
    <!-- Menú Horizaontal -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="../Index.php">Aretesanias Catacaos</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/inicioAdmin.php">Inicio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/GestionarProd.php">Gestionar Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/VerOrden.php">Ver Pedidos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/VerReclamos.php">Ver Reclamos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../admin/VerPagos.php">Ver Pagos</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="content">

        <h1 class="text-center">Panel de Administración</h1>
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Bienvenido, <?php echo $_SESSION['usuario_Nombre']; ?></h2>
            <a href="../CerrarSesion.php" class="btn btn-danger">Cerrar Sesión</a>
            <a href="exportar_dashboard.php" class="btn btn-primary">Exportar a PDF</a>

        </div>

        <div class="container my-4">
            <div class="row">
                <!-- Tarjeta: Número de Usuarios -->
                <div class="col-md-3">
                    <a href="GestionarUsuarios.php" class="text-decoration-none">
                        <div class="card text-white bg-primary mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Usuarios Registrados</h5>
                                <p class="card-text display-4"><?php echo mysqli_num_rows($resultUsuarios); ?></p>
                            </div>
                        </div>
                    </a>
                </div>

                <!-- Tarjeta: Número de Productos -->
                <div class="col-md-3">
                    <a href="GestionarProd.php" class="text-decoration-none">
                        <div class="card text-white bg-success mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Productos Registrados</h5>
                                <p class="card-text display-4"><?php echo mysqli_num_rows($resultProductos); ?></p>
                            </div>
                        </div>
                    </a>
                </div>

                <!-- Tarjeta: Pedidos Pendientes -->
                <div class="col-md-3">
                    <a href="VerOrden.php" class="text-decoration-none">
                        <div class="card text-white bg-warning mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Pedidos Pendientes</h5>
                                <p class="card-text display-4">
                                    <?php
                                    $queryPedidosPendientes = "SELECT * FROM orden WHERE Estado = 'pendiente'";
                                    $resultPedidosPendientes = mysqli_query($conn, $queryPedidosPendientes);
                                    echo mysqli_num_rows($resultPedidosPendientes);
                                    ?>
                                </p>
                            </div>
                        </div>
                    </a>
                </div>

                <!-- Tarjeta: Reclamos Pendientes -->
                <div class="col-md-3">
                    <a href="VerReclamos.php" class="text-decoration-none">
                        <div class="card text-white bg-danger mb-3">
                            <div class="card-body">
                                <h5 class="card-title">Reclamos Pendientes</h5>
                                <p class="card-text display-4">
                                    <?php
                                    $queryReclamosPendientes = "SELECT * FROM reclamos WHERE Estado = 'pendiente'";
                                    $resultReclamosPendientes = mysqli_query($conn, $queryReclamosPendientes);
                                    echo mysqli_num_rows($resultReclamosPendientes);
                                    ?>
                                </p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>


            <div class="container">
                <!-- Primera fila de gráficos -->
                <div class="row">
                    <div class="col-6 text-center">
                        <h5>Productos Entregados</h5>
                        <canvas id="graficaEntregadosPorMes" style="max-height: 200px; max-width: 90%;"></canvas>
                    </div>
                    <div class="col-6 text-center">
                        <h5>Reclamaciones</h5>
                        <canvas id="graficaReclamaciones" style="max-height: 200px; max-width: 90%;"></canvas>
                    </div>
                </div>

                <!-- Segunda fila de gráficos -->
                <div class="row mt-4">
                    <div class="col-12 text-center">
                        <h5>Distribución de Productos</h5>
                        <canvas id="graficaProductos" style="max-height: 200px; max-width: 90%;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
            const entregadosPorMes = <?php echo json_encode($entregadosPorMes); ?>;
            const reclamacionesEstado = <?php echo json_encode($reclamacionesEstado); ?>;
            const productosMasVendidos = <?php echo json_encode($productosMasVendidos); ?>;
            const ctxEntregados = document.getElementById('graficaEntregadosPorMes').getContext('2d');
            const entregadosLabels = entregadosPorMes.map(item => `Mes ${item.mes}`);
            const entregadosData = entregadosPorMes.map(item => item.total);
            new Chart(ctxEntregados, {
                type: 'bar',
                data: {
                    labels: entregadosLabels,
                    datasets: [{
                        label: 'Pedidos Entregados',
                        data: entregadosData,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                }
            });

            const ctxReclamaciones = document.getElementById('graficaReclamaciones').getContext('2d');
            const reclamacionesLabels = reclamacionesEstado.map(item => item.Estado);
            const reclamacionesData = reclamacionesEstado.map(item => item.total);
            new Chart(ctxReclamaciones, {
                type: 'pie',
                data: {
                    labels: reclamacionesLabels,
                    datasets: [{
                        label: 'Reclamaciones',
                        data: reclamacionesData,
                        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
                    }]
                }
            });

            const ctxProductos = document.getElementById('graficaProductos').getContext('2d');
            const productosLabels = productosMasVendidos.map(item => item.Nombre_Producto);
            const productosData = productosMasVendidos.map(item => item.total);
            new Chart(ctxProductos, {
                type: 'bar',
                data: {
                    labels: productosLabels,
                    datasets: [{
                        label: 'Productos Más Vendidos',
                        data: productosData,
                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1
                    }]
                }
            });
        </script>


        <!-- Tabla de Usuarios -->
        <h2 class="my-4">Usuarios</h2>
        <table class="table table-bordered table-striped">
            <thead class="table-success">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Rol</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($resultUsuarios) > 0) {
                    while ($row = mysqli_fetch_assoc($resultUsuarios)) {
                        echo "<tr>";
                        echo "<td>" . $row['Id_Usuario'] . "</td>";
                        echo "<td>" . $row['Nombre'] . "</td>";
                        echo "<td>" . $row['Correo'] . "</td>";
                        echo "<td>" . $row['Id_Rol'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' class='text-center'>No se encontraron usuarios</td></tr>";
                } ?>
            </tbody>
        </table>
        <!-- Tabla de Artesanos -->
        <h2 class="my-4">Lista de Artesanos</h2>
        <table class="table table-bordered table-striped">
            <thead class="table-success">
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido</th>
                    <th>Contacto</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($resultArtesanos) > 0) {
                    while ($row = mysqli_fetch_assoc($resultArtesanos)) {
                        echo "<tr>";
                        echo "<td>" . $row['Id_Artesano'] . "</td>";
                        echo "<td>" . $row['Nombre'] . "</td>";
                        echo "<td>" . $row['Apellido'] . "</td>";
                        echo "<td>" . $row['Contacto'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No se encontraron artesanos</td></tr>"; // Corregido el colspan a 5
                }
                ?>
            </tbody>
        </table>


        <!-- Tabla de Productos -->
        <h2 class="my-4">Productos</h2>
        <table class="table table-bordered table-striped">
            <thead class="table-success">
                <tr>
                    <th>ID Producto</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($resultProductos) > 0) {
                    while ($row = mysqli_fetch_assoc($resultProductos)) {
                        echo "<tr>";
                        echo "<td>" . $row['Id_Producto'] . "</td>";
                        echo "<td>" . $row['Nombre'] . "</td>";
                        echo "<td>" . $row['Descripcion'] . "</td>";
                        echo "<td>" . $row['Precio'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' class='text-center'>No se encontraron productos</td></tr>";
                } ?>
            </tbody>
        </table>

        <!-- Tabla de Pedidos -->
        <h2 class="my-4">Lista de Pedidos</h2>
        <table class="table table-bordered table-striped">
            <thead class="table-success">
                <tr>
                    <th>ID Orden</th>
                    <th>Fecha</th>
                    <th>Total</th>
                    <th>Usuario</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($resultOrdenes) > 0) {
                    while ($row = mysqli_fetch_assoc($resultOrdenes)) {
                        echo "<tr>";
                        echo "<td>" . $row['Id_Orden'] . "</td>";
                        echo "<td>" . $row['Fecha'] .  "</td>";
                        echo "<td>" .  $row['Total'] . "</td>";
                        echo "<td>" . $row['Nombre'] . " " . $row['Apellido'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4' class='text-center'>No se encontraron pedidos</td></tr>";
                } ?>
            </tbody>
        </table>
    </div>



</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


</html>