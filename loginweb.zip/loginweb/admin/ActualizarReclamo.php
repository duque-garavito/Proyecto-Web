<?php
@include '../Conexion.php';

session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('location:../Login.php');
}

// Verifica que se ha recibido una solicitud POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_reclamo = $_POST['id_reclamo'];
    $estado = $_POST['estado'];

    // Actualiza el estado del reclamo en la base de datos
    $queryActualizar = "UPDATE reclamos SET estado = ? WHERE id_reclamo = ?";
    $stmt = $conn->prepare($queryActualizar);
    $stmt->bind_param('si', $estado, $id_reclamo);

    if ($stmt->execute()) {
        // Redirige de vuelta a la página de reclamos con un mensaje de éxito
        header('Location: VerReclamos.php?mensaje=Estado actualizado correctamente');
        exit();
    } else {
        // Manejo de errores
        echo "Error al actualizar el estado: " . $conn->error;
    }
} else {
    // Redirige si no es una solicitud POST
    header('Location: VerReclamos.php');
    exit();
}
?>
