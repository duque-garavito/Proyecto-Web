<?php
@include '../Conexion.php';

session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('location:../Login.php');
    exit();
}

$queryPagos = "SELECT * FROM pagos";
$resultPagos = mysqli_query($conn, $queryPagos);

$mensaje = '';
if (isset($_GET['mensaje'])) {
    $mensaje = $_GET['mensaje'];
}

// Función para obtener la ruta del comprobante con extensión existente
function obtenerRutaComprobante($id_pago) {
    $extensiones = ['jpg', 'png', 'pdf'];
    foreach ($extensiones as $ext) {
        $ruta = "../comprobantes/$id_pago.$ext";
        if (file_exists($ruta)) {
            return $ruta;
        }
    }
    return null; // No se encontró el archivo
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Pagos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/Menuadmin.css">
</head>
<body>
    <div class="sidebar">
        <img src="../imagenes/LOGO.png" alt="Logo">
        <a href="../admin/inicioAdmin.php">Inicio</a>
        <a href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a>
        <a href="../admin/GestionarProd.php">Gestionar Productos</a>
        <a href="../admin/VerOrden.php">Ver Pedidos</a>
        <a href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a>
        <a href="../admin/VerReclamos.php">Ver Reclamos</a>
        <a href="../admin/VerPagos.php">Ver Pagos</a>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Artesanías Catacaos</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="../admin/inicioAdmin.php">Inicio</a></li>
                    <li class="nav-item"><a class="nav-link" href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a></li>
                    <li class="nav-item"><a class="nav-link" href="../admin/GestionarProd.php">Gestionar Productos</a></li>
                    <li class="nav-item"><a class="nav-link" href="../admin/VerOrden.php">Ver Pedidos</a></li>
                    <li class="nav-item"><a class="nav-link" href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a></li>
                    <li class="nav-item"><a class="nav-link" href="../admin/VerReclamos.php">Ver Reclamos</a></li>
                    <li class="nav-item"><a class="nav-link" href="../admin/VerPagos.php">Ver Pagos</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="content">
        <div class="container mt-5">
            <h2 class="text-center mb-4">Ver Pagos</h2>
            <?php if ($mensaje): ?>
                <div class="alert alert-info"><?php echo $mensaje; ?></div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-bordered table-striped text-center">
                    <thead class="table-dark">
                        <tr>
                            <th>ID Pago</th>
                            <th>ID Orden</th>
                            <th>Fecha de Pago</th>
                            <th>Método de Pago</th>
                            <th>Monto</th>
                            <th>Comprobante</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($resultPagos) > 0) {
                            while ($row = mysqli_fetch_assoc($resultPagos)) {
                                echo "<tr>";
                                echo "<td>" . $row['id_pago'] . "</td>";
                                echo "<td>" . $row['id_orden'] . "</td>";
                                echo "<td>" . $row['fecha_pago'] . "</td>";
                                echo "<td>" . $row['metodo_pago'] . "</td>";
                                echo "<td>" . number_format($row['monto'], 2) . " soles</td>";
                                
                                // Llama a la función para obtener la ruta del comprobante
                                $rutaComprobante = obtenerRutaComprobante($row['id_pago']);
                                if ($rutaComprobante) {
                                    echo "<td>
                                        <a href='$rutaComprobante' target='_blank' class='btn btn-info btn-sm'>
                                            Ver Comprobante
                                        </a>
                                      </td>";
                                } else {
                                    echo "<td>No disponible</td>";
                                }

                                echo "<td>" . $row['estado'] . "</td>";
                                echo "<td>
                                        <form action='ActualizarPago.php' method='POST' class='d-inline'>
                                            <input type='hidden' name='id_pago' value='" . $row['id_pago'] . "'>
                                            <select name='estado' class='form-select form-select-sm' required>
                                                <option value='pendiente'" . ($row['estado'] === 'pendiente' ? ' selected' : '') . ">Pendiente</option>
                                                <option value='confirmado'" . ($row['estado'] === 'confirmado' ? ' selected' : '') . ">Confirmado</option>
                                                <option value='rechazado'" . ($row['estado'] === 'rechazado' ? ' selected' : '') . ">Rechazado</option>
                                            </select>
                                            <button type='submit' class='btn btn-success btn-sm'>Actualizar</button>
                                        </form>
                                        
                                      </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8'>No se encontraron pagos</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div class="text-center mt-4">
                <a href="inicioAdmin.php" class="btn btn-primary">Volver al inicio</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
