<?php
require('../fpdf.php'); // Asegúrate de usar la ruta correcta
include('../Conexion.php'); // Archivo de conexión a la base de datos

class PDF extends FPDF
{
    // Encabezado del PDF
    function Header()
    {
        $this->SetFont('Arial', 'B', 14);
        $this->Cell(0, 10, 'Reporte del Dashboard', 0, 1, 'C');
        $this->Ln(5);
    }

    // Pie de página
    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Pagina ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }

    // Tabla genérica
    function Table($header, $data)
    {
        $this->SetFont('Arial', 'B', 12);
        foreach ($header as $col) {
            $this->Cell(48, 7, $col, 1, 0, 'C');
        }
        $this->Ln();

        $this->SetFont('Arial', '', 10);
        foreach ($data as $row) {
            foreach ($row as $col) {
                $this->Cell(48, 6, $col, 1);
            }
            $this->Ln();
        }
    }
}

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

// ** Usuarios Registrados **
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Usuarios Registrados', 0, 1, 'L');
$pdf->Ln(2);

// Consulta para los usuarios
$queryUsuarios = "SELECT Id_Usuario, Nombre, Correo, Id_Rol FROM usuario";
$result = $conn->query($queryUsuarios);
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [$row['Id_Usuario'], $row['Nombre'], $row['Correo'], $row['Id_Rol']];
}
$header = ['ID', 'Nombre', 'Correo', 'Rol'];
$pdf->Table($header, $data);
$pdf->Ln(10);

// ** Productos Registrados **
$pdf->Cell(0, 10, 'Productos Registrados', 0, 1, 'L');
$pdf->Ln(2);

// Consulta para los productos
$queryProductos = "SELECT Id_Producto, Nombre, Descripcion, Precio FROM productos";
$result = $conn->query($queryProductos);
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [$row['Id_Producto'], $row['Nombre'], $row['Descripcion'], $row['Precio']];
}
$header = ['ID Producto', 'Nombre', 'Descripcion', 'Precio'];
$pdf->Table($header, $data);
$pdf->Ln(10);

// ** Pedidos Registrados **
$pdf->Cell(0, 10, 'Pedidos Registrados', 0, 1, 'L');
$pdf->Ln(2);

// Consulta para los pedidos
$queryOrdenes = "SELECT o.Id_Orden, o.Fecha, o.Total, CONCAT(u.Nombre, ' ', u.Apellido) AS Usuario
                 FROM orden o
                 JOIN usuario u ON o.Id_Usuario = u.Id_Usuario";
$result = $conn->query($queryOrdenes);
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [$row['Id_Orden'], $row['Fecha'], $row['Total'], $row['Usuario']];
}
$header = ['ID Orden', 'Fecha', 'Total', 'Usuario'];
$pdf->Table($header, $data);
$pdf->Ln(10);

// ** Reclamos Registrados **
$pdf->Cell(0, 10, 'Reclamos Registrados', 0, 1, 'L');
$pdf->Ln(2);

// Consulta para los reclamos
$queryReclamos = "SELECT Estado, COUNT(*) AS Total FROM reclamos GROUP BY Estado";
$result = $conn->query($queryReclamos);
$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = [$row['Estado'], $row['Total']];
}
$header = ['Estado', 'Total'];
$pdf->Table($header, $data);
$pdf->Ln(10);

// Salida del PDF
$pdf->Output('D', 'dashboard.pdf');
exit;
?>
