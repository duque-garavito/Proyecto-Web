<?php 
@include '../Conexion.php';

$queryOrdenes = "SELECT o.Id_Orden, o.Fecha, o.Total, o.Estado, u.Nombre AS Nombre_Usuario
                 FROM orden o
                 JOIN usuario u ON o.Id_Usuario = u.Id_Usuario";
$resultOrdenes = mysqli_query($conn, $queryOrdenes);

if (isset($_POST['Id_Orden']) && isset($_POST['Estado']) && is_numeric($_POST['Id_Orden'])) {
    $idOrden = $_POST['Id_Orden'];
    $estado = $_POST['Estado'];

    $queryActualizar = "UPDATE orden SET Estado = ? WHERE Id_Orden = ?";
    if ($stmt = mysqli_prepare($conn, $queryActualizar)) {
        mysqli_stmt_bind_param($stmt, 'si', $estado, $idOrden);
        if (mysqli_stmt_execute($stmt)) {
            header('Location: admin/VerOrden.php?mensaje=actualizado');
            exit();
        } else {
            header('Location: admin/VerOrden.php?error=actualizar');
            exit();
        }
        mysqli_stmt_close($stmt);
    } else {
        header('Location: admin/VerOrden.php?error=preparar');
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Órdenes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/Menuadmin.css">

</head>
<body>
<div class="sidebar">
      <img src="../imagenes/LOGO.png" alt="Logo">
      <a href="../admin/inicioAdmin.php">Inicio</a>
      <a href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a>
      <a href="../admin/GestionarProd.php">Gestionar Productos</a>
      <a href="../admin/VerOrden.php">Ver Pedidos</a>
      <a href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a>
      <a href="../admin/VerReclamos.php">Ver Reclamos</a>
      <a href="../admin/VerPagos.php">Ver Pagos</a>
      </div>

        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container-fluid">
         <a class="navbar-brand" href="#">Aretesanias Catacaos</a>
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                  <a class="nav-link" href="../admin/inicioAdmin.php">Inicio</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/GestionarProd.php">Gestionar Productos</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/VerOrden.php">Ver Pedidos</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/VerReclamos.php">Ver Reclamos</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/VerPagos.php">Ver Pagos</a>
               </li>
            </ul>
         </div>
      </div>
   </nav>

<div class="content">
    <div class="container mt-5">
    <h2 class="text-center mb-4">Gestión de Ordenes</h2>
    
    <?php
    if (isset($_GET['mensaje']) && $_GET['mensaje'] == 'actualizado') {
        echo "<div class='alert alert-success text-center'>El estado de la orden se ha actualizado correctamente.</div>";
    } elseif (isset($_GET['error'])) {
        echo "<div class='alert alert-danger text-center'>Hubo un error al procesar la solicitud.</div>";
    }
    ?>
    
    

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-center">
            <thead class="table-dark">
                <tr>
                    <th>ID Orden</th>
                    <th>Usuario</th>
                    <th>Fecha Creación</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($resultOrdenes) > 0) {
                    while ($row = mysqli_fetch_assoc($resultOrdenes)) {
                        echo "<tr>";
                        echo "<td>" . $row['Id_Orden'] . "</td>";
                        echo "<td>" . $row['Nombre_Usuario'] . "</td>";
                        echo "<td>" . $row['Fecha'] . "</td>";
                        echo "<td>" . number_format($row['Total'], 2) . " soles</td>";
                        
                        echo "<td>
                                <form action='../admin/ActualizarEstado.php' method='POST'>
                                    <input type='hidden' name='Id_Orden' value='" . $row['Id_Orden'] . "'>
                                    <select name='Estado' class='form-select'>
                                        <option value='Pendiente'" . ($row['Estado'] == 'Pendiente' ? ' selected' : '') . ">Pendiente</option>
                                        <option value='Entregado'" . ($row['Estado'] == 'Entregado' ? ' selected' : '') . ">Entregado</option>
                                        <option value='Cancelado'" . ($row['Estado'] == 'Cancelado' ? ' selected' : '') . ">Cancelado</option>
                                    </select>
                            </td>";
                        
                        echo "<td>
                                <button type='submit' class='btn btn-success btn-sm'>Actualizar</button>
                                <a href='../admin/DetalleOrden.php?id=" . $row['Id_Orden'] . "' class='btn btn-info btn-sm'>Ver Detalle</a>
                                </form>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No se encontraron órdenes</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
</div>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</html>
