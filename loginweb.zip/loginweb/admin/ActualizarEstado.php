<?php
include '../Conexion.php';

if (isset($_POST['Id_Orden']) && isset($_POST['Estado']) && is_numeric($_POST['Id_Orden'])) {
    $idOrden = $_POST['Id_Orden'];
    $estado = $_POST['Estado'];

    $query = "UPDATE orden SET Estado = ? WHERE Id_Orden = ?";
    
    if ($stmt = mysqli_prepare($conn, $query)) {
        mysqli_stmt_bind_param($stmt, 'si', $estado, $idOrden);

        if (mysqli_stmt_execute($stmt)) {
            echo "<script>
                    alert('Estado de la orden actualizado exitosamente');
                    window.location.href = '../admin/VerOrden.php';
                  </script>";
        } else {
            
            error_log("Error al actualizar el estado: " . mysqli_stmt_error($stmt)); // Registro del error
            echo "<script>
                    alert('Error al actualizar el estado');
                    window.location.href = '../admin/VerOrden.php';
                  </script>";
        }

        
        mysqli_stmt_close($stmt);
    } else {
        
        error_log("Error en la preparación de la consulta: " . mysqli_error($conn)); // Registro del error
        echo "<script>
                alert('Error al procesar la solicitud');
                window.location.href = '../admin/VerOrden.php';
              </script>";
    }
} else {
    header('Location: ../admin/VerOrden.php');
    exit(); 
}


mysqli_close($conn);
?>
