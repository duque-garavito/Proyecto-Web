<?php
@include '../Conexion.php';

session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('location:../Login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_pago = $_POST['id_pago'];
    $estado = $_POST['estado'];

    // Verifica que el estado no esté vacío
    if (empty($estado)) {
        header("Location: VerPagos.php?mensaje=El estado no puede estar vacío.");
        exit();
    }

    $queryActualizar = "UPDATE pagos SET estado = ? WHERE id_pago = ?";
    $stmt = mysqli_prepare($conn, $queryActualizar);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'si', $estado, $id_pago);
        if (mysqli_stmt_execute($stmt)) {
            header("Location: VerPagos.php?mensaje=Pago actualizado correctamente.");
            exit();
        } else {
            header("Location: VerPagos.php?mensaje=Error al actualizar el pago.");
            exit();
        }
    } else {
        header("Location: VerPagos.php?mensaje=Error en la consulta de actualización.");
        exit();
    }
} else {
    header("Location: VerPagos.php");
    exit();
}
?>
