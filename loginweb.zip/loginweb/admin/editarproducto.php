<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center mb-4">Editar Producto</h2>

    <?php
    @include '../Conexion.php';
    session_start();
    if (!isset($_SESSION['usuario_id'])) {
        header('location:../Login.php');
        exit;
    }

    // Obtener el ID del producto a editar
    $id_producto = $_GET['id'];
    $query = "SELECT * FROM productos WHERE Id_Producto = $id_producto";
    $result = mysqli_query($conn, $query);
    $producto = mysqli_fetch_assoc($result);

    // Verificar si el formulario fue enviado
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nombrep = mysqli_real_escape_string($conn, $_POST['nombre']);
        $descripcion = mysqli_real_escape_string($conn, $_POST['descripcion']);
        $precio = mysqli_real_escape_string($conn, $_POST['precio']);
        $stock = mysqli_real_escape_string($conn, $_POST['stock']);
        $id_artesano = mysqli_real_escape_string($conn, $_POST['artesano']);
        
        // Actualizar los datos del producto
        $queryUpdate = "UPDATE productos SET Nombre='$nombrep', Descripcion='$descripcion', Precio='$precio', Cantidad='$stock', Id_Artesano='$id_artesano' WHERE Id_Producto='$id_producto'";
        
        if (mysqli_query($conn, $queryUpdate)) {
            echo "<div class='alert alert-success'>Producto actualizado exitosamente.</div>";
        } else {
            echo "<div class='alert alert-danger'>Error al actualizar el producto: " . mysqli_error($conn) . "</div>";
        }

        // Procesar la nueva imagen (si se subió una)
        if (!empty($_FILES['imagen']['name'])) {
            $carpeta = "../imagenes/$id_producto";
            if (!file_exists($carpeta)) {
                mkdir($carpeta, 0777, true);
            }

            $imagen = $_FILES['imagen']['name'];
            $imagenTmp = $_FILES['imagen']['tmp_name'];
            $rutaImagen = "$carpeta/principal.jpg";

            if (move_uploaded_file($imagenTmp, $rutaImagen)) {
                $queryImageUpdate = "UPDATE productos SET Imagen = '$rutaImagen' WHERE Id_Producto = '$id_producto'";
                if (!mysqli_query($conn, $queryImageUpdate)) {
                    echo "<div class='alert alert-danger'>Error al actualizar la imagen del producto.</div>";
                }
            }
        }
    }

    // Obtener lista de artesanos
    $queryArtesanos = "SELECT Id_Artesano, Nombre, Apellido FROM artesano";
    $resultArtesanos = mysqli_query($conn, $queryArtesanos);
    ?>

    <form method="POST" action="" enctype="multipart/form-data">
        <div class="mb-3 col-md-4">
            <label for="nombre" class="form-label">Nombre:</label>
            <input type="text" id="nombre" name="nombre" class="form-control" value="<?php echo $producto['Nombre']; ?>" required>
        </div>

        <div class="mb-3 col-md-4">
            <label for="descripcion" class="form-label">Descripción:</label>
            <input type="text" id="descripcion" name="descripcion" class="form-control" value="<?php echo $producto['Descripcion']; ?>" required>
        </div>

        <div class="mb-3 col-md-4">
            <label for="precio" class="form-label">Precio:</label>
            <input type="number" id="precio" name="precio" class="form-control" step="0.01" value="<?php echo $producto['Precio']; ?>" required>
        </div>

        <div class="mb-3 col-md-4">
            <label for="stock" class="form-label">Stock:</label>
            <input type="number" id="stock" name="stock" class="form-control" value="<?php echo $producto['Cantidad']; ?>" required>
        </div>

        <div class="mb-3 col-md-4">
            <label for="artesano" class="form-label">Artesano:</label>
            <select id="artesano" name="artesano" class="form-control" required>
                <?php
                while ($artesano = mysqli_fetch_assoc($resultArtesanos)) {
                    $selected = ($artesano['Id_Artesano'] == $producto['Id_Artesano']) ? 'selected' : '';
                    echo "<option value='" . $artesano['Id_Artesano'] . "' $selected>" . $artesano['Nombre'] . " " . $artesano['Apellido'] . "</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="imagen" class="form-label">Nueva Imagen del Producto (opcional):</label>
            <input type="file" id="imagen" name="imagen" class="form-control" accept="image/*">
        </div>

        <button type="submit" class="btn btn-primary">Actualizar Producto</button>
        <a href="GestionarProd.php" class="btn btn-secondary">Regresar</a>
    </form>
</div>
</body>
</html>
