<?php
@include '../Conexion.php';

// Verificar si se ha recibido el ID del artesano
if (isset($_GET['id'])) {
   $id = $_GET['id'];
   $query = "SELECT * FROM artesano WHERE Id_Artesano = '$id'";
   $result = mysqli_query($conn, $query);

   if (mysqli_num_rows($result) > 0) {
      $artesano = mysqli_fetch_assoc($result);
   } else {
      echo "<div class='alert alert-danger'>Artesano no encontrado.</div>";
      exit;
   }
}

// Actualizar los datos del artesano
if (isset($_POST['update'])) {
   $nombre = mysqli_real_escape_string($conn, $_POST['Nombre']);
   $apellido = mysqli_real_escape_string($conn, $_POST['Apellido']);
   $contacto = mysqli_real_escape_string($conn, $_POST['Contacto']);
   $error = [];

   if (empty($nombre) || empty($apellido)) {
      $error[] = 'El nombre y apellido son obligatorios.';
   }

   if (empty($error)) {
      $update = "UPDATE artesano SET 
                 Nombre = '$nombre', 
                 Apellido = '$apellido', 
                 Contacto = " . (!empty($contacto) ? "'$contacto'" : "NULL") . " 
                 WHERE Id_Artesano = '$id'";

      if (mysqli_query($conn, $update)) {
         echo "<div class='alert alert-success'>Datos actualizados correctamente.</div>";
      } else {
         echo "<div class='alert alert-danger'>Error al actualizar: " . mysqli_error($conn) . "</div>";
      }
   } else {
      foreach ($error as $msg) {
         echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($msg) . '</div>';
      }
   }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Artesano</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center">Editar Artesano</h2>
    <form action="" method="post">
        <div class="mb-3 col-md-4">
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" class="form-control" name="Nombre" value="<?php echo htmlspecialchars($artesano['Nombre']); ?>" required>
        </div>
        <div class="mb-3 col-md-4">
            <label for="apellido" class="form-label">Apellido</label>
            <input type="text" class="form-control" name="Apellido" value="<?php echo htmlspecialchars($artesano['Apellido']); ?>" required>
        </div>
        <div class="mb-3 col-md-4">
            <label for="contacto" class="form-label">Contacto</label>
            <input type="text" class="form-control" name="Contacto" value="<?php echo htmlspecialchars($artesano['Contacto']); ?>" placeholder="Teléfono o Email (opcional)">
        </div>
        <button type="submit" name="update" class="btn btn-primary">Actualizar Artesano</button>
        <a href="GestionarArtesanos.php" class="btn btn-secondary">Regresar</a>
    </form>
</div>
</body>
</html>
