<?php

include '../Conexion.php'; 


if (isset($_GET['id'])) {
    $id = $_GET['id'];


    $sql = "DELETE FROM usuario WHERE id_Usuario = ?";


    if ($stmt = $conn->prepare($sql)) {

        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "Usuario eliminado exitosamente.";
            header("Location: GestionarUsuarios.php"); 
        } else {
            echo "Error al eliminar el usuario.";
        }
    } else {
        echo "Error en la consulta SQL.";
    }


    $stmt->close();
} else {
    echo "No se ha proporcionado un ID válido.";
}


$conn->close();
?>
