<?php
@include '../Conexion.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>
            alert('ID de orden no proporcionado');
            window.location.href = 'admin/VerOrden.php';
          </script>";
    exit();
}

$idOrden = $_GET['id'];

$queryDetalleOrden = "SELECT do.*, p.Nombre AS NombreProducto, p.Precio 
                      FROM detalle_orden do
                      JOIN productos p ON do.Id_Producto = p.Id_Producto
                      WHERE do.Id_Orden = ?";
$stmt = $conn->prepare($queryDetalleOrden);
$stmt->bind_param("i", $idOrden);
$stmt->execute();
$resultDetalleOrden = $stmt->get_result();

$queryOrden = "SELECT * FROM orden WHERE Id_Orden = ?";
$stmtOrden = $conn->prepare($queryOrden);
$stmtOrden->bind_param("i", $idOrden);
$stmtOrden->execute();
$resultOrden = $stmtOrden->get_result();
$orden = $resultOrden->fetch_assoc();

if (!$orden) {
    echo "<script>
            alert('Orden no encontrada');
            window.location.href = 'admin/VerOrden.php';
          </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle de la Orden</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

<div class="container mt-5">
    <h1 class="text-center mb-4">Detalle de la Orden #<?php echo htmlspecialchars($orden['Id_Orden']); ?></h1>
    
    <div class="mb-4">
        <p><strong>Fecha de Orden:</strong> <?php echo htmlspecialchars($orden['Fecha']); ?></p>
        <p><strong>Estado:</strong> <?php echo htmlspecialchars($orden['Estado']); ?></p>
        <p><strong>Total:</strong> <?php echo number_format($orden['Total'], 2); ?> soles</p>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-striped text-center">
            <thead class="table-dark">
                <tr>
                    <th>Producto</th>
                    <th>Precio Unitario</th>
                    <th>Cantidad</th>
                    <th>Total</th> 
                </tr>
            </thead>
            <tbody>
                <?php
                $total = 0; 
                if ($resultDetalleOrden->num_rows > 0) {
                    while ($detalle = $resultDetalleOrden->fetch_assoc()) {
                        $nombreProducto = $detalle['NombreProducto'];
                        $precio = $detalle['Precio'];
                        $cantidad = $detalle['Cantidad'];
                        $subtotal = $precio * $cantidad; 

                        $total += $subtotal; 

                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($nombreProducto) . "</td>";
                        echo "<td>" . number_format($precio, 2) . " soles</td>";
                        echo "<td>" . $cantidad . "</td>";
                        echo "<td>" . number_format($subtotal, 2) . " soles</td>"; // Mostrar subtotal
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No se encontraron detalles para esta orden</td></tr>";
                }
                ?>
                <tr>
                    <td colspan="3" class="text-end fw-bold">Total</td>
                    <td class="fw-bold"><?php echo number_format($total, 2); ?> soles</td> <!-- Total calculado -->
                </tr>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <a href="VerOrden.php" class="btn btn-secondary">Volver a Órdenes</a>
    </div>
</div>

</body>
</html>

<?php
$stmt->close();
$stmtOrden->close();
$conn->close();
?>
