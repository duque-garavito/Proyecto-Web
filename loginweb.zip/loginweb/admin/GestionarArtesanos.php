<?php
@include '../Conexion.php';

if (isset($_POST['submit'])) {
   $nombre = mysqli_real_escape_string($conn, $_POST['Nombre']);
   $apellido = mysqli_real_escape_string($conn, $_POST['Apellido']);
   $contacto = mysqli_real_escape_string($conn, $_POST['Contacto']); // Puede ser vacío o contener texto
   $error = [];


   if (empty($nombre) || empty($apellido)) {
      $error[] = 'El nombre y apellido son obligatorios.';
   }


   if (empty($error)) {

      $insert = "INSERT INTO artesano (Nombre, Apellido, Contacto) 
                 VALUES ('$nombre', '$apellido', " . (!empty($contacto) ? "'$contacto'" : "NULL") . ")"; // Corregido: cerrar el paréntesis

      if (mysqli_query($conn, $insert)) {
         echo "<div class='alert alert-success'>Artesano registrado exitosamente.</div>";
      } else {
         echo "<div class='alert alert-danger'>Error al registrar el artesano: " . mysqli_error($conn) . "</div>"; // Añadido para mostrar el error de la consulta
      }
   } else {
 
      foreach ($error as $msg) {
         echo '<div class="alert alert-danger" role="alert">' . htmlspecialchars($msg) . '</div>';
      }
   }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/adminPro.css"> 
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/Menuadmin.css">
</head>
<body>
<div class="sidebar">
      <img src="../imagenes/LOGO.png" alt="Logo">
      <a href="../admin/inicioAdmin.php">Inicio</a>
      <a href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a>
      <a href="../admin/GestionarProd.php">Gestionar Productos</a>
      <a href="../admin/VerOrden.php">Ver Pedidos</a>
      <a href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a>
      <a href="../admin/VerReclamos.php">Ver Reclamos</a>
      <a href="../admin/VerPagos.php">Ver Pagos</a>
</div>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container-fluid">
         <a class="navbar-brand" href="#">Aretesanias Catacaos</a>
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                  <a class="nav-link" href="../admin/inicioAdmin.php">Inicio</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/GestionarUsuarios.php">Gestionar Usuarios</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/GestionarProd.php">Gestionar Productos</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/VerOrden.php">Ver Pedidos</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/GestionarArtesanos.php">Gestionar Artesanos</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/VerReclamos.php">Ver Reclamos</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="../admin/VerPagos.php">Ver Pagos</a>
               </li>
            </ul>
         </div>
      </div>
</nav>
<div class="content">
<h2 class="text-center mb-4">Gestión de Artesanos</h2>
<div class="container mt-5">
    <h4 class="text-center mb-4">Registrar Nuevo Artesano</h4>
    <form action="" method="post" class="form">
        <div class="row justify-content-center mb-3 col-md-4">
            <label for="nombre" class="form-label mt-5">Nombre</label>
            <input type="text" class="form-control" name="Nombre" required>
        </div>
        <div class="row justify-content-center mb-3 col-md-4">
            <label for="apellido" class="form-label">Apellido</label>
            <input type="text" class="form-control" name="Apellido" required>
        </div>
        <div class="row justify-content-center mb-3 col-md-4">
            <label for="Contacto" class="form-label">Contacto (Teléfono o Email)</label>
            <input type="text" name="Contacto" id="Contacto" class="form-control" placeholder="Ingresa un número o correo (opcional)">
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Registrar Artesano</button>
    </form>
</div>
<?php
// Obtener la lista de artesanos
$query = "SELECT * FROM artesano";
$resultArtesanos= mysqli_query($conn, $query);
?>

<div class="container mt-5">
    <h2>Lista de Artesanos</h2>
    <table class="table table-bordered table-striped">
        <thead class="table-success">
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Contacto</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($resultArtesanos) > 0) {
                while ($row = mysqli_fetch_assoc($resultArtesanos)) {
                    echo "<tr>";
                    echo "<td>" . $row['Id_Artesano'] . "</td>";
                    echo "<td>" . $row['Nombre'] . "</td>";
                    echo "<td>" . $row['Apellido'] . "</td>";
                    echo "<td>" . $row['Contacto'] . "</td>";
                    echo "<td>
                            <a href='editarArtesano.php?id=" . $row['Id_Artesano'] . "' class='btn btn-warning btn-sm'>Editar</a>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5' class='text-center'>No se encontraron artesanos</td></tr>"; // Corregido el colspan a 5
            }
            ?>
        </tbody>
    </table>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
